<?php

define("WEBSITE_TITLE", 'DSKBATH');

// for server
define('DB_NAME', 'creatrzy_test_dskbath_db');
define('DB_USER', 'creatrzy_developerCM3');
define('DB_PASSWORD', 'DeveloperCM3');

// for localhost
// define('DB_NAME', 'dskbath_db');
// define('DB_USER','root');
// define('DB_PASSWORD', '');

define('DB_TYPE', "mysql");
define("DB_HOST", 'localhost');

define('THEME', 'dskbath/');

define('DEBUG', true);

// if (DEBUG) {
//     ini_set('display_errors',1);
// } else {
//     ini_set('display_errors',1);
// }


// ini_set('display_errors',1);